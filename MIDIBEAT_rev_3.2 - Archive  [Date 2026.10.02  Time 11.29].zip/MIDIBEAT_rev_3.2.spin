{{
+==============================================================================+
|                                                                              |
|                              M I D I B E A T                                |
|                Propeller P1 "algorithmic" MIDI Drum Sequencer                |
|                                                                              |
+==============================================================================+

  Author   : Tony Friel ("Tony Spiner" on the forum) + AI helpers: e.g. Claude, DeepSeek
  File     : MIDIBEAT_rev_3.2.spin
  Version  : 3.2  simplied transport to use only 2 buttons, reduced OLED contrast in driver  
  Date     : 02/10/2026

  To do: 
        - live layer (button 09?)
        - additional rhythm algorithms and randomness   
        - pattern storage and recall
        - improved audio output
        - MIDI input for clock and transport
        - more sophisticated SWING and FLAM
        - OLED 'anti-aging' features
  
--------------------------------------------------------------------------------
 OVERVIEW
--------------------------------------------------------------------------------
  Intended as a project for learning Propeller P1 coding and exploring 'Euclidean' drum rhythms,      
  MIDIBEAT is in development on a Propeller Proto USB board with external modules and custom PCBs.
  Objective is to transmit patterns of MIDI messages based on user configured algorithms. 

  A step-engine running in a dedicated COG cycles through 24 steps. At each step the main program
  algorithm decides if a hit should be sent for each of the 2 channels KIT and PERC.

  The current step in the cycle and the Euclidean patterns are displayed on two RGB LED rings,
  (each ring is 24 WS2812B LEDs). The "HIT" algorithm is included in the Euclid1 method. Other
  algorithms should be experemented with.

  The user interface inputs feature 8 rotary encoders and 16 push buttons. These are used to set the
  Euclidean pattern parameters k, n and o, control transport functions and adjust the play speed.
  2 push-buttons set the encoder mode for KIT and PERC: primary mode to adjust Euclidan parameters,
  alt mode for MIDI notes (drums) and MIDI velocity values. 
 
  MASTER SPI OLED displays:
  -MIDIBEAT version
  -MIDIBEAT status (READY, RUNNING, PAUSED, STOPPED)
  -FLAM time
  -SWING status
  -STEP, SPB, BPM

  KIT and PERC SPI OLEDs display:
  -k,n,o values
  -Drum name and a velocity bargraph
  -FLAM status, MIDI port (A or B) and encoder mode (PRI or ALT)
  
  A 16 digit, 7-segment LED display module shows STEP, STP, BPM and Euclid pattern values. It includes
  indictor LEDs for MIDIBEAT status and encoder mode for KIT and PERC.
       
-------------------------------------------------------------------------------------------
Propeller P1 I/O pin assignments 
------------------------------------------------------------------------------------------- 

P00 - timing debug toggle signal - Main loop 
P01 - timing debug toggle signal - Step engine object
P02 - ********FREE***************  'could be a UI object toggle debug?
P03 - encoder/push-button PCB QH - serial data input from nearest 74HC165 Pin 9
P04 - encoder/push-button PCB CK - clock output to 74HC165 Pin 10        *
P05 - encoder/push-button PCB SH/LD - load data output to 74HC165 Pin 11 *
P06 - ********FREE***************
P07 - serial data TX to WS2812B 2 x 24 RGB LED rings  (uses Proto USB board servo header)

P08 -  ********FREE***************                         
P09 -  ********FREE***************                         
P10 - PWM/PDM audio                                            
P11 - PWM/PDM audio                                           
P12 - reserved for KIT  hit trigger output pulse         
P13 - reserved for PERC hit trigger output pulse        
P14 - MIDI buffer enable (active-low)
P15 - ********FREE***************                       

P16 - OLED SPI 1   CLOCK        * OLED_CLK    
P17 - OLED SPI 2   DATA         * OLED_DATA
P18 - OLED SPI 4   RESET        * OLED_RST
P19 - OLED SPI 5   DC             OLED_DC
P20 - OLED SPI 6   CS             OLED_CS_1
P21 - MAX7219 --------------------- LED PCB CLK    
P22 - MAX7219  2 x 8-digit,7-seg    LED PCB CS             
P23 - MAX7219 --------------------- LED PCB DATA           

P24 - OLED_CS_2                            
P25 - OLED_CS_3       
P26 - MIDI TX1 tx to buffer IC port A 
P27 - MIDI TX2 tx to buffer IC port B
P28 - I2C SCL connection to EEPROM
P29 - I2C SDA connection to EEPROM
P30 - Serial Tx to host
P31 - Serial Rx from host

* = fit a 100 Ohm resistor on the Propeller side.
+==============================================================================+

--------------------------------------------------------------------------------
 MIDIBEAT STATEs   (UI-selectable; drives step-engine state)
--------------------------------------------------------------------------------
  +-------+-----------+--------------------------------------------------------+
  | State | Name      | MIDIBEAT behaviour                                     |
  +-------+-----------+--------------------------------------------------------+
  | 0     | STOPPED   | Step-engine halted. UI and display continue running,   |
  |       |  "STOP"   | but no KIT or PERC hits are sent.                      |
  |       |           | Pressing PLAY starts MIDIBEAT at step 1.               |
  +-------+-----------+--------------------------------------------------------+  
  | 1     | RUNNING   | Step-engine runs; MIDI messages etc. are sent.         |
  |       | "PLAY"    |                                                        |
  +-------+-----------+--------------------------------------------------------+    
  | 2     | PAUSED    | Step advance is halted, current step held.             |
  |       | "PAUSE"   | Pressing PLAY resumes MIDIBEAT at the next step.       |
  +-------+-----------+--------------------------------------------------------+

--------------------------------------------------------------------------------
 User Interface

 - Launched in a separate COG
 - Drives 3 SPIN OLED display
 - Monitors push buttons and encoders.
--------------------------------------------------------------------------------   
 2 MIDI output ports
 
 - via 2/4 channels of a +5V Logic IC buffer with common /enable
 - Uses FullDuplexSerial4portPlus serial object in own COG.
--------------------------------------------------------------------------------
 STEP-ENGINE
 
  Runs in its own COG; reads BPM, SPB, step-position and SWING, publishes ring_position
  1 - 24 when running or paused; 0 when stopped
  
--------------------------------------------------------------------------------
 FLAM 
 
  Sends an extra Note ON/OFF pair (at reduced  velocity) a short time after the normal hit, on the same step.
  - flam_enable_KIT / flam_enable_PERC are set by the push-buttons.
  - FLAM_time is adjustable via encoder
 
--------------------------------------------------------------------------------
 SWING  (timing shuffle)

  "Swing" delays alternate (usually even-numbered) steps slightly so the
  rhythm has a shuffled, less mechanical/robotic feel, rather than every
  step landing on a perfectly even grid.

  - SWING (VAR, in this file) is a single global percentage: 50 = straight
    (no swing/shuffle), up to 75 = maximum shuffle. It is UI-adjustable.
    
  - SWING value is passed by pointer into the step-engine

-------------------------------------------------------------------------------
Inputs object buttons function reference table 

 Bits 00-07 = PERC (PCB2) buttons 1-8
 Bits 08-15 = KIT  (PCB1) buttons 9-16

 +-------+----------------------------------------------+
 | Bit  | Function                                      |               
 +------+-----------------------------------------------+
 | 00   | PERC encoder A button = unused                |          
 +------+-----------------------------------------------+  
 | 01   | PERC encoder B button = unused                |            
 +------+-----------------------------------------------+    
 | 02   | PERC encoder C button = unused                |
 +------+-----------------------------------------------+
 | 03   | PERC encoder D button = unused                |
 +------+-----------------------------------------------+  
 | 04   | PERC button D (bottom on PCB) = FLAM toggle   |       
 +------+-----------------------------------------------+    
 | 05   | PERC button C = unused                        |    
 +------+-----------------------------------------------+
 | 06   | PERC button B = PERC MIDI output port toggle  |
 +------+-----------------------------------------------+ 
 | 07   | PERC button A = PERC encoders mode            |     
 +------+-----------------------------------------------+
 | 08   | KIT encoder A button = MASTER encoders mode   |
 +------+-----------------------------------------------+   
 | 09   | KIT encoder B button + **** live hit ****     | 
 +------+-----------------------------------------------+   
 | 10   | KIT encoder C button + ** PLAY/PAUSE button **|
 +------+-----------------------------------------------+  
 | 11   | KIT encoder D button + **** STOP button ****  |
 +------+-----------------------------------------------+   
 | 12   | KIT button D (bottom on PCB)= FLAM toggle     | 
 +------+-----------------------------------------------+  
 | 13   | KIT button C = SWING toggle                   | 
 +------+-----------------------------------------------+  
 | 14   | KIT button B = KIT MIDI output port toggle    | 
 +------+-----------------------------------------------+  
 | 15   | KIT button A = KIT encoders mode              | 
 +------+-----------------------------------------------+

}}

OBJ                                          'Objects included in MIDIBEAT
                                             '--------------------------------------------------
  midi    : "FullDuplexSerial4port"          'Tracy Allen quad serial object    
  strip   : "jm_ws2812b"                     'Jon McPhalen WS2812B RGB LED driver object
  OLEDs   : "3_SPI_OLED"                     '3 x SPI OLED object
  inputs  : "MIDIBEAT_encoders_buttons"      '32-bits parallel to serial data clocked-in object
  stepper : "MIDIBEAT_step_engine"           'Step sequence generator object
  drum    : "MIDIBEAT_Drum_2"                'Stereo "Syntom" audio generator object
  LED7SEG : "MAX7219_16_3"                   '16 digit 7-segment display driver object
                                             '---------------------------------------------------
                                                               
CON
  _xinfreq = 5_000_000
  _clkmode = xtal1 + pll16x       '5 MHz * 16 = 80 MHz system clock

  OLED_CLK   = 16                  'SPI OLEDs I/O pins
  OLED_DATA  = 17 
  OLED_RST   = 18 
  OLED_DC    = 19
  OLED_CS_1  = 20
  OLED_CS_2  = 24
  OLED_CS_3  = 25
  
  #0, PIXEL_OFF, PIXEL_ON, PIXEL_XOR
  #1, FONT_NORM, FONT_WIDE, FONT_BIG, FONT_PLX 
  MASTER = 1  
  KIT    = 2
  PERC   = 3
      
  LEDS          = 7              'I/O pin for WS2812B RGB LED strings
  STRIP_LEN     = 48             '48 LEDs: 2 x rings of 24
  PIX_BITS      = 24                
  RED           = $10_00_00_00   'WS2812B colour codes
  BRIGHT_RED    = $A0_00_00_00 
  GREEN         = $00_10_00_00
  BRIGHT_GREEN  = $00_A0_00_00   
  GREY          = $01_01_01_00
  VIOLET        = $0C_08_0C_00

  DATA_PIN      = 23             'I/O pin for data to MAX7219 
  CLK_PIN       = 21             'I/O pin for clock to MAX7219
  CS_PIN        = 22             'I/O pin for enable to MAX7219
  BRIGHT1       = 10             'brightness level for digits 1-8
  BRIGHT2       = 12             'brightness level for digits 9-16

  enc_DATA_PIN  = 3              'I/O pin for 74HC165 serial data
  enc_CLOCK_PIN = 4              'I/O pin for 74HC165 clock
  enc_LOAD_PIN  = 5              'I/O pin for 74HC165 load
  
  ALT_MASTER_BTN = 8             'MASTER alt toggle (BPM + SPB encoders)
  ALT_GROUP1_BTN = 15            'KIT   alt toggle (n,k,o encoders)
  ALT_GROUP2_BTN = 7             'PERC  alt toggle (n,k,o encoders)
  MIDI_PORT_KIT_BTN  = 14        'toggle MIDI output ports
  MIDI_PORT_PERC_BTN = 6
  SWING_BTN          = 13        'toggle SWING OFF(50%)/ON(65%)
  SWING_OFF          = 50        'straight timing, no shuffle
  SWING_ON           = 65        'shuffled timing
  FLAM_KIT_BTN       = 12        'toggle FLAM on KIT
  FLAM_PERC_BTN      = 4         'toggle FLAM on PERC
  

  MIDI_BAUD    = 31_250          'MIDI BAUD rate
  MIDI_TX_1    = 26              'I/O pin MIDI out PORT A
  MIDI_TX_2    = 27              'I/O pin MIDI out PORT B
  MIDI_RX      = 15              'I/O pin for MIDI IN
  MIDI_ENABLE  = 14              'I/O pin to enable MIDI out buffer
  MIDI_NOTE_ON_CHN10  = 153      '$99 MIDI message
  MIDI_NOTE_OFF_CHN10 = 137      '$89 MIDI message

  KIT_audio_PIN                 = 10   'I/O pin for KIT audio    
  PERC_audio_PIN                = 11   'I/O pin for PERC audio      
  KIT_trigger_PIN               = 12   'I/O pin for a KIT trigger pulse
  PERC_trigger_PIN              = 13   'I/O pin for a PERC trigger pulse

  monitor_PIN_main_loop = 0             'debug toggle signal in main loop

DAT    
{{ Encoder function config table: "Primary" is default, "Alt" when toggled

Encoder: Primary         Group    Alt
1        BPM             MASTER   ALT_MASTER_1 (separate variable)
2        n_KIT           KIT      vel_KIT
3        k_KIT           KIT      drum_idx_KIT
4        o_KIT           KIT      ALT_KIT_4 (separate variable)
5        SPB             MASTER   FLAM_time 
6        n_PERC          PERC     vel_PERC
7        k_PERC          PERC     drum_idx_PERC
8        o_PERC          PERC     ALT_PERC_4(separate variable)

}}
'-------------------------------------------------------------------------------------------------------
'             enc1*      enc2    enc3    enc4                   enc5*     enc6       enc7      enc8
'             -----     ----    ----    ----                     ----     ----     ----      ----
'              BPM     n_KIT   k_KIT   o_KIT                    SPB    n_PERC     k_PERC    o_PERC
prim_min  long  20,       2,      0,       0,                     1,       2,         0,        0
prim_init long 120,      8,       5,       0,                       2,       24,        11,        0
prim_max  long 280,      24,     24,       8,                     8,      24,         24,       8
prim_sens long   8,       8,     16,      16,                     8,       8,        16,       16

'             ALT_KIT_1  vel_KIT  drum_KIT ALT_KIT_4      FLAM_time   vel_PERC   drum_PERC   ALT_PERC_4
alt_min   long   0,       1,      1,         0,                   01,         1,           1,       0
alt_init  long   0,       80,     15,        0,                   10,         80,          16,      20
alt_max   long   0,     127,     24,        0,                    100,       127,          24,     100
alt_sens  long   1,       1,      8,        32,                    8,         1,           8,       4

' *enc1 and enc 5 belong to MASTER
'--------------------------------------------------------------------------------------------------------
' YAMAHA DD-55 DRUM TABLE (24 entries, index 1-24)
'                 idx:  1      2      3      4      5      6
'                 idx:  7      8      9      10     11     12
'                 idx:  13     14     15     16     17     18
'                 idx:  19     20     21     22     23     24      
drum_note       long   33,    35,    38,    40,    39,    54
                long   50,    48,    45,    42,    46,    49
                long   65,    66,    61,    60,    68,    67                       
                long   69,    70,    75,    77,    76,    81
                
drum_flam_note  long   33,    35,    40,    38,    54,    39
                long   50,    45,    48,    46,    42,    44
                long   66,    65,    61,    60,    67,    68
                long   69,    70,    75,    77,    76,    82
                                                                                          
drum_name       byte  "BDSOFT", 0, "BDHARD", 0, "SNARE1", 0, "SNARE2", 0, "CLAP  ", 0, "TAMBOR", 0
                byte  "TOM_HI", 0, "TOM_MD", 0, "TOM_LO", 0, "HH_CLS", 0, "HH_OPN", 0, "CRASH1", 0
                byte  "TIMBLH", 0, "TIMBLL", 0, "BONGOH", 0, "BONGOL", 0, "AGOGOH", 0, "AGOGOL", 0
                byte  "CABASA", 0, "MARACA", 0, "CLAVES", 0, "BLOCKH", 0, "BLOCKL", 0, "TRIANG", 0
'------------------------------------------------------------------------------------------------------
   
VAR
  long UI_stack[512]            'stack space for UI COG
 
  long pixbuf1[STRIP_LEN]       'RGB LED data array

  long Live_layer_KIT[24]
  long Live_layer_PERC[24] 
  long Patt_len, BPM, SPB
  
  long ring_position, old_ring_position

  long n_KIT, n_PERC, k_KIT, k_PERC, o_KIT, o_PERC
  long prev_n_KIT, prev_k_KIT, prev_o_KIT
  long prev_n_PERC, prev_k_PERC, prev_o_PERC
 
  long drum_idx_KIT, drum_idx_PERC
  long vel_KIT, vel_PERC              
  long MIDI_port_KIT, previous_MIDI_port_KIT, MIDI_port_PERC, previous_MIDI_port_PERC

  long Euclid_KIT_changed, Euclid_PERC_changed
  long engine_state                 '0=stopped, 1=running, 2=paused
  long prev_engine_state
  long SWING                        'global swing percent: 50=straight ... 75=max shuffle
  long flam_enable_KIT              '0=off, 1=on
  long flam_enable_PERC             '0=off, 1=on
                

  long FLAM_ticks
  long FLAM_time
 
  long MIDI_port_dirty    
  long oled_dirty_MASTER '1 = MASTER display needs update     
  long oled_dirty_KIT    '1 = KIT display needs update  
  long oled_dirty_PERC   '1 = PERC display needs update 

  long current_port        '
  long old_enc[8]
  long buttons, prev_buttons, old_buttons

  long alt_val[8]
  long prim_target[8]
  long alt_target[8]

  long alt_group1_active     'KIT'    encoders mode
  long alt_group2_active     'PERC'   encoders mode 
  long alt_group3_active     'MASTER' encoders mode (BPM + SPB)
  long alt_raw[8]

 'long primary_shadow[8]  ' Complete set of primary mode shadow values for encoder modes

  long ALT_MASTER_1         'MASTER alt target for encoder 1 (BPM) - TBD
  long ALT_KIT_4            'KIT    alt target for encoder 4 (o_KIT) - TBD
  long ALT_PERC_4           'PERC   alt target for encoder 8 (o_PERC) - TBD
  long KIT_start_pitch, KIT_end_pitch, KIT_sweep_duration
  long PERC_start_pitch, PERC_end_pitch, PERC_sweep_duration


PUB main                                 'Main Program Method
'*********************************************************************************
  DIRA[monitor_PIN_main_loop] := 1       'debug toggle pin is an output
  OUTA[monitor_PIN_main_loop] := 0       'set low
  DIRA[MIDI_ENABLE] := 1                 'MIDI buffers
  OUTA[MIDI_ENABLE] := 1                 'disabled

  DIRA[KIT_audio_PIN] := 1               'audio pin is output
  DIRA[PERC_audio_PIN] := 1              'audio pin is output 
  ' pull SPI OLED reset here?
 
  MIDI_port_KIT  := 0                    'default port select is A for KIT
  MIDI_port_PERC := 0                    'default port select is A for PERC
  previous_MIDI_port_KIT  := MIDI_port_KIT
  previous_MIDI_port_PERC := MIDI_port_PERC
  Patt_len := 24
  prev_buttons := 255
  old_ring_position := 0
  engine_state := 0 'engine is stopped

  'assign initial vales from Encoder config table 
  BPM           := long[@prim_init][0]
  n_KIT         := long[@prim_init][1]
  k_KIT         := long[@prim_init][2]
  o_KIT         := long[@prim_init][3]
  SPB           := long[@prim_init][4]
  n_PERC        := long[@prim_init][5]
  k_PERC        := long[@prim_init][6]
  o_PERC        := long[@prim_init][7]

  ALT_MASTER_1  := long[@alt_init][0]   
  vel_KIT       := long[@alt_init][1]
  drum_idx_KIT  := long[@alt_init][2]
  ALT_KIT_4     := long[@alt_init][3]
  FLAM_time     := long[@alt_init][4]  
  vel_PERC      := long[@alt_init][5]
  drum_idx_PERC := long[@alt_init][6]
  ALT_PERC_4    := long[@alt_init][7]  
  '--------------------------------------------
  flam_enable_KIT  := 0
  flam_enable_PERC := 0
  FLAM_ticks := 2_000_000
  SWING := SWING_OFF    
  prev_n_KIT := n_KIT
  prev_k_KIT := k_KIT
  prev_o_KIT := o_KIT
  prev_n_PERC := n_PERC
  prev_k_PERC := k_PERC
  prev_o_PERC := o_PERC            
  
  KIT_start_pitch     := 800
  KIT_end_pitch       := 600
  KIT_sweep_duration  := 200

  PERC_start_pitch    := 3000
  PERC_end_pitch      := 3000
  PERC_sweep_duration := 20

'******************************************************************************************
'************* launch the UI code in a separate COG   *************************************
  cognew(UI, @UI_stack)
 '******************************************************************************************           

'******************************************************************************************   
'************ SETUP the two MIDI ports (FullDuplexSerial4portPlus) serial object  *********
'******************************************************************************************  
  midi.init
  waitcnt(cnt + clkfreq/100)     
  midi.AddPort(0, -1, MIDI_TX_1, -1, -1, 0, 0, MIDI_BAUD)
  waitcnt(cnt + clkfreq/100)
  midi.AddPort(1, -1, MIDI_TX_2, -1, -1, 0, 0, MIDI_BAUD)
  waitcnt(cnt + clkfreq/100)
  midi.Start
  waitcnt(cnt + clkfreq/100)     

'******************************************************************************************   
'************************  SETUP THE "inputs" 32-bit serial object   **********************
'******************************************************************************************
  inputs.start(enc_DATA_PIN, enc_CLOCK_PIN, enc_LOAD_PIN, 1)
  waitcnt(cnt + clkfreq/200)
  inputs.reset_latch
  init_encoders
  waitcnt(cnt + clkfreq/100)


'******************************************************************************************
'**********    get the step engine object     *************************************
  stepper.start(@ring_position, @Patt_len, @BPM, @SPB, @engine_state, @SWING)
  waitcnt(cnt + clkfreq/10)


'******************************************************************************************   
'***********    start-up the Jon McPhalen RGB LED strip driver object          ************
  strip.start(@pixbuf1, STRIP_LEN, LEDS)
  waitcnt(cnt + clkfreq/100)
'******************************************************************************************

'******************************************************************************************
'****************  light-up the RGS LED rings   *******************************************
  show_euclid_pattern
'******************************************************************************************

                                        
'*******************  enable the MIDI output buffers **************************************   
  OUTA[MIDI_ENABLE]  := 0 

'******************************************************************************************


'************ start the digital drum audio object *****************************************
 drum.start(KIT_audio_PIN, PERC_audio_PIN)
 drum.Set_KIT(KIT_start_pitch,KIT_end_pitch,KIT_sweep_duration)
 drum.Set_PERC(PERC_start_pitch,PERC_end_pitch,PERC_sweep_duration)

'******************************************************************************************


'************************* MAIN PROGRAM LOOP ***********************************************
   '

  repeat
    !outa[monitor_PIN_main_loop]

    case engine_state
      0: 'stopped
        check_euclid
        waitcnt(cnt + clkfreq/200)
        ' system settings could be updated whilst MIDIBEAT is stopped.   

      1: 'running
        check_euclid
        if ring_position <> old_ring_position
        
          if old_ring_position > 0
            if Euclid1(old_ring_position, n_KIT, k_KIT, o_KIT) == -1
              pixbuf1[old_ring_position-1] := RED
              
            else
              pixbuf1[old_ring_position-1] := GREY
              
            if Euclid1(old_ring_position, n_PERC, k_PERC, o_PERC) == -1
              pixbuf1[old_ring_position+23] := GREEN
                
            else
              pixbuf1[old_ring_position+23] := GREY
              
          old_ring_position := ring_position
           
           handle_KIT_hit 
           handle_PERC_hit
           waitcnt(cnt + FLAM_ticks) 'Delay for any FLAM hits
                   
           if flam_enable_KIT  
             handle_KIT_FLAM
             
          if flam_enable_PERC  
            handle_PERC_FLAM 

      2: 'paused
        check_euclid
        waitcnt(cnt + clkfreq/200)

'*****************************************************************************************  
'*****************************************************************************************


PRI handle_KIT_hit |  midi_note
  ' Only process hits when engine is running
  if engine_state == 1
    ' Check if current step has a KIT hit
    if Euclid1(ring_position, n_KIT, k_KIT, o_KIT) == -1
      
      ' Get the drum MIDI note to play
      midi_note := GetDrumNote(drum_idx_KIT)
      ' PLAY AUDIO 
      drum.play_drum(0)  ' PWM audio output for KIT

      ' --- MAIN MIDI HIT (plays BEFORE any flam) ---
      ' Send the main MIDI note on the selected port
      midi.tx(MIDI_port_KIT, MIDI_NOTE_ON_CHN10)
      midi.tx(MIDI_port_KIT, midi_note)
      midi.tx(MIDI_port_KIT, vel_KIT)
      
      waitcnt(cnt + 1000)   
      midi.tx(MIDI_port_KIT, MIDI_NOTE_OFF_CHN10)
      midi.tx(MIDI_port_KIT, midi_note)
      midi.tx(MIDI_port_KIT, 0)

      ' --- LED FEEDBACK ---
      ' Light the current KIT LED bright red (hit)
      pixbuf1[ring_position-1] := BRIGHT_RED
      waitcnt(cnt + 80_000)  ' Brief flash duration
    else
      ' No hit - show violet to indicate step position
      pixbuf1[ring_position-1] := VIOLET

PRI handle_PERC_hit | midi_note
  ' Only process hits when engine is running
  if engine_state == 1
    ' Check if current step has a PERC hit
    if Euclid1(ring_position, n_PERC, k_PERC, o_PERC) == -1
      
      ' Get the drum note to play
      midi_note := GetDrumNote(drum_idx_PERC)
         
      ' --- MAIN MIDI HIT
      ' Send the main MIDI note on the selected port
      midi.tx(MIDI_port_PERC, MIDI_NOTE_ON_CHN10)
      midi.tx(MIDI_port_PERC, midi_note)
      midi.tx(MIDI_port_PERC, vel_PERC)
      waitcnt(cnt + 1000)
      
      midi.tx(MIDI_port_PERC, MIDI_NOTE_OFF_CHN10)
      midi.tx(MIDI_port_PERC, midi_note)
      midi.tx(MIDI_port_PERC, 0)
      
      ' --- LED FEEDBACK ---
      ' Light the current PERC LED bright green (hit)
      pixbuf1[ring_position+23] := BRIGHT_GREEN   
      waitcnt(cnt + 80_000)  ' Brief flash duration
    else
      ' No hit - show violet to indicate step position
      pixbuf1[ring_position+23] := VIOLET


PRI handle_KIT_FLAM | flam_vel, midi_note, flam_note
  ' Only process hits when engine is running
  if engine_state == 1
    ' Check if current step has a KIT hit
    if Euclid1(ring_position, n_KIT, k_KIT, o_KIT) == -1

       ' Get the flam note to play  
        flam_note := GetDrumFlam(drum_idx_KIT)     
        flam_vel := (vel_KIT/4)*3     'slightly less, could be adjustable
        if flam_vel < 1
          flam_vel := 1  ' Minimum velocity of 1
        
        ' Send flam note on the SAME port as main hit
        midi.tx(MIDI_port_KIT, MIDI_NOTE_ON_CHN10)
        midi.tx(MIDI_port_KIT, flam_note)
        midi.tx(MIDI_port_KIT, flam_vel)

        ' Send flam note-off
        midi.tx(MIDI_port_KIT, MIDI_NOTE_OFF_CHN10)
        midi.tx(MIDI_port_KIT, flam_note)
        midi.tx(MIDI_port_KIT, 0)
      


PRI handle_PERC_FLAM | flam_vel, midi_note, flam_note
  ' Only process hits when engine is running
  if engine_state == 1
    ' Check if current step has a PERC hit
    if Euclid1(ring_position, n_PERC, k_PERC, o_PERC) == -1
      
      ' Get the flam note to play
        flam_note := GetDrumFlam(drum_idx_PERC)
        flam_vel := (vel_PERC/4)*3   'slightly less  
        if flam_vel < 1
          flam_vel := 1  ' Minimum velocity of 1
        
        ' Send flam note on the SAME port as main hit
        midi.tx(MIDI_port_PERC, MIDI_NOTE_ON_CHN10)
        midi.tx(MIDI_port_PERC, flam_note)
        midi.tx(MIDI_port_PERC, flam_vel)
         
        ' Send flam note-off
        midi.tx(MIDI_port_PERC, MIDI_NOTE_OFF_CHN10)
        midi.tx(MIDI_port_PERC, flam_note)
        midi.tx(MIDI_port_PERC, 0)
  

PUB GetDrumNote(idx) : note
  if idx => 1 and idx =< 24
    note := drum_note[idx-1]
  else
    note := 36

PUB GetDrumFlam(idx) : flam
  if idx => 1 and idx =< 24
    flam := drum_flam_note[idx-1]
  else
    flam := 35

PUB GetDrumName(idx) : name_ptr
  if idx => 1 and idx =< 24
    name_ptr := @drum_name + ((idx-1) * 7)
  else
    name_ptr := @err_name
    
PUB FLAM_time_check | step_ms, safe_max_ms 
  step_ms := 60000 / (BPM * SPB) 
  safe_max_ms := step_ms / 2

  if  FLAM_time > safe_max_ms
     FLAM_time := safe_max_ms
     alt_val[4] := safe_max_ms 'feedback to encoder
     oled_dirty_KIT  := 1
     oled_dirty_PERC := 1
     oled_dirty_MASTER := 1
  FLAM_ticks := FLAM_time * (clkfreq / 1000)

DAT
err_name        byte  "ERR   ",0    ' if the GetDrumName fails


PUB UI    

'===================================================================================
' UI - Runs in its own COG
'===================================================================================

  ' ============================================================
  '  SPI OLEDs
  ' ============================================================
   init_OLEDs
   ' ============================================================    
   ' Show MASTER OLED 
    OLEDs.select_display(MASTER)
    OLEDs.goto_xy(0, 0)
    OLEDs.str(string("MIDIBEAT"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(68, 0)
    OLEDs.str(string(" READY "), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(0, 2)
    OLEDs.str(string("Ft="), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(52, 2)
    OLEDs.str(string("Swing="), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(2, 4)
    OLEDs.str(string("STEP"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(46, 4)
    OLEDs.str(string("SPB"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(54, 6)  
    OLEDs.rjdec(SPB, 1, "0", FONT_BIG, PIXEL_ON)
    OLEDs.goto_xy(90, 4)
    OLEDs.str(string("BPM"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(80, 6)  
    OLEDs.rjdec(BPM, 3, "0", FONT_BIG, PIXEL_ON)

    oled_dirty_MASTER := 1

  ' ============================================================
  ' Show KIT OLED    
    OLEDs.select_display(KIT)
    OLEDs.box(0, 0, 40, 30, PIXEL_ON)
    OLEDs.box(42, 0, 82, 30,PIXEL_ON)
    OLEDs.box(84, 0, 116,30, PIXEL_ON)  
    OLEDs.goto_xy(3, 0) 
    OLEDs.str(string("k"), FONT_NORM, PIXEL_ON) 
    OLEDs.goto_xy(46, 0) 
    OLEDs.str(string("n"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(88, 0) 
    OLEDs.str(string("o"), FONT_NORM, PIXEL_ON)
    oled_dirty_KIT := 1
    
  ' ============================================================
  ' Show PERC  OLED

    OLEDs.select_display(PERC)
    OLEDs.box(0, 0, 40, 30, PIXEL_ON)
    OLEDs.box(42, 0, 82, 30,PIXEL_ON)
    OLEDs.box(84, 0, 116,30, PIXEL_ON)  
    OLEDs.goto_xy(3, 0) 
    OLEDs.str(string("k"), FONT_NORM, PIXEL_ON) 
    OLEDs.goto_xy(46, 0) 
    OLEDs.str(string("n"), FONT_NORM, PIXEL_ON)
    OLEDs.goto_xy(88, 0) 
    OLEDs.str(string("o"), FONT_NORM, PIXEL_ON)
    oled_dirty_PERC := 1 


' ===============7-segment display board =========================  
    
  LED7SEG.Start(DATA_PIN, CLK_PIN, CS_PIN, BRIGHT1, BRIGHT2)
  LED7SEG.LeadingZero(0)


  ' ============================================================
  '  Main UI Loop
  ' ============================================================
  repeat   
    read_encoders_buttons
    waitcnt(cnt + clkfreq/1000)  ' 1ms delay

    update_oled_STEP    'fast step number update MASTER OLED 

    if buttons <> prev_buttons
      prev_buttons := buttons

      if ((buttons & (1 << 11)) == 0)   ' STOP button
        stepper.stop
        ring_position := 0
        old_ring_position := 0
        show_euclid_pattern
          
    if inputs.get_button_latched(10)     ' PAUSE/PLAY toggle button
      case engine_state
        0: 'STOPPED -> RUN
         stepper.resume
        1: ' RUNNING -> PAUSE
          stepper.pause
        2: ' PAUSED -> RESUME
          stepper.resume

    max7219_display

     if oled_dirty_MASTER
      update_oled_MASTER  
    if oled_dirty_KIT
      update_oled_KIT
    if oled_dirty_PERC
      update_oled_PERC

    if  engine_state <>  prev_engine_state
       prev_engine_state := engine_state
        OLEDs.select_display(MASTER)
       case engine_state
         0:
            
            OLEDs.goto_xy(68, 0)
            OLEDs.str(string("STOPPED"), FONT_NORM, PIXEL_ON)
         1:  
            OLEDs.goto_xy(68, 0)
            OLEDs.str(string("RUNNING"), FONT_NORM, PIXEL_ON)
         2:  
            OLEDs.goto_xy(68, 0)
            OLEDs.str(string("PAUSED  "), FONT_NORM, PIXEL_ON)

     

 
PUB read_encoders_buttons | i, raw, delta, min_raw, max_raw, is_alt, delta_step

  ' ============================================================
  '  MASTER ALT toggle  (encoders 1 and 5 = BPM and SPB)
  ' ============================================================
   if inputs.get_button_latched(ALT_MASTER_BTN)
    !alt_group3_active
    if alt_group3_active == 1
      ' Switching FROM primary TO alt mode
      ' Resync alt_val so first encoder turn starts from current values
      alt_val[0] := ALT_MASTER_1
      alt_val[4] := FLAM_time
      ' Reset MASTER encoders (1,5) to match alt values
      inputs.set_encoder(1, ALT_MASTER_1 * long[@prim_sens][0])
      old_enc[0] := inputs.get_encoder(1)
      inputs.set_encoder(5, FLAM_time * long[@prim_sens][4])
      old_enc[4] := inputs.get_encoder(5)
    else
      ' Switching FROM alt TO primary mode
      ' Reset MASTER encoders (1,5) to match primary values
      inputs.set_encoder(1, BPM * long[@prim_sens][0])
      old_enc[0] := inputs.get_encoder(1)
      inputs.set_encoder(5, SPB * long[@prim_sens][4])
      old_enc[4] := inputs.get_encoder(5)
    oled_dirty_MASTER := 1

  ' ============================================================
  '  KIT ALT toggle  (encoders 2,3,4 = n_KIT,k_KIT,o_KIT)
  ' ============================================================
  if inputs.get_button_latched(ALT_GROUP1_BTN)
    !alt_group1_active
    if alt_group1_active == 1
      ' Switching FROM primary TO alt mode
      ' Reset KIT encoders (2,3,4) to match alt values
      inputs.set_encoder(2, vel_KIT * long[@prim_sens][1])
      old_enc[1] := inputs.get_encoder(2)
      inputs.set_encoder(3, drum_idx_KIT * long[@prim_sens][2])
      old_enc[2] := inputs.get_encoder(3)
      inputs.set_encoder(4, ALT_KIT_4 * long[@prim_sens][3])
      old_enc[3] := inputs.get_encoder(4)
    else
      ' Switching FROM alt TO primary mode
      ' Reset KIT encoders (2,3,4) to match primary values
      inputs.set_encoder(2, n_KIT * long[@prim_sens][1])
      old_enc[1] := inputs.get_encoder(2)
      inputs.set_encoder(3, k_KIT * long[@prim_sens][2])
      old_enc[2] := inputs.get_encoder(3)
      inputs.set_encoder(4, o_KIT * long[@prim_sens][3])
      old_enc[3] := inputs.get_encoder(4)
    oled_dirty_KIT := 1

  ' ============================================================
  '  PERC ALT toggle  (encoders 6,7,8 = n_PERC,k_PERC,o_PERC)
  ' ============================================================
  if inputs.get_button_latched(ALT_GROUP2_BTN)
    !alt_group2_active
    if alt_group2_active == 1
      ' Switching FROM primary TO alt mode
      ' Reset PERC encoders (6,7,8) to match alt values
      inputs.set_encoder(6, vel_PERC * long[@prim_sens][5])
      old_enc[5] := inputs.get_encoder(6)
      inputs.set_encoder(7, drum_idx_PERC * long[@prim_sens][6])
      old_enc[6] := inputs.get_encoder(7)
      inputs.set_encoder(8, ALT_PERC_4 * long[@prim_sens][7])
      old_enc[7] := inputs.get_encoder(8)
    else
      ' Switching FROM alt TO primary mode
      ' Reset PERC encoders (6,7,8) to match primary values
      inputs.set_encoder(6, n_PERC * long[@prim_sens][5])
      old_enc[5] := inputs.get_encoder(6)
      inputs.set_encoder(7, k_PERC * long[@prim_sens][6])
      old_enc[6] := inputs.get_encoder(7)
      inputs.set_encoder(8, o_PERC * long[@prim_sens][7])
      old_enc[7] := inputs.get_encoder(8)
    oled_dirty_PERC := 1

  if inputs.get_button_latched(MIDI_PORT_KIT_BTN)
    MIDI_port_KIT ^= 1
    oled_dirty_KIT :=1 
    
  if inputs.get_button_latched(MIDI_PORT_PERC_BTN)
    MIDI_port_PERC ^= 1
    oled_dirty_PERC :=1

  if inputs.get_button_latched(SWING_BTN)
    if SWING == SWING_OFF
      SWING := SWING_ON
    else
      SWING := SWING_OFF
    oled_dirty_MASTER := 1

    
  if inputs.get_button_latched(FLAM_KIT_BTN)
    flam_enable_KIT ^= 1
    oled_dirty_KIT := 1
    
  if inputs.get_button_latched(FLAM_PERC_BTN)
    flam_enable_PERC ^= 1
    oled_dirty_PERC := 1
    
  buttons := inputs.get_buttons

repeat i from 0 to 7   ' reads 8 encoders, each with two modes
  raw := inputs.get_encoder(i + 1)
  if raw <> old_enc[i]
    delta := raw - old_enc[i]

    if (i == 0) or (i == 4)
      is_alt := alt_group3_active      ' MASTER: encoders 1 and 5
    elseif i < 4
      is_alt := alt_group1_active      ' KIT:    encoders 2,3,4
    else
      is_alt := alt_group2_active      ' PERC:   encoders 6,7,8

    if is_alt
      ' ALT MODE - Process all alt parameters
      alt_raw[i] += delta
      delta_step := 0
      
      if alt_raw[i] => long[@alt_sens][i]
        delta_step := alt_raw[i] / long[@alt_sens][i]
        alt_raw[i] //= long[@alt_sens][i]
      elseif alt_raw[i] =< -long[@alt_sens][i]
        delta_step := alt_raw[i] / long[@alt_sens][i]
        alt_raw[i] //= long[@alt_sens][i]

      if delta_step <> 0
        alt_val[i] := long[@alt_min][i] #> (alt_val[i] + delta_step) <# long[@alt_max][i]
        if alt_target[i] <> 0
          long[alt_target[i]] := alt_val[i]
        case i    
          0:      oled_dirty_MASTER := 1   ' MASTER encoder 1 (ALT_MASTER_1)
          1..3:   oled_dirty_KIT := 1      ' KIT encoders 2,3,4
          4:      FLAM_time_check          ' MASTER encoder 5 (FLAM_time)
                   oled_dirty_MASTER := 1
          5..7:   oled_dirty_PERC := 1     ' PERC encoders 6,7,8
       
    else
      ' PRIMARY MODE - Process all Euclidean parameters
      min_raw := long[@prim_min][i] * long[@prim_sens][i]
      max_raw := long[@prim_max][i] * long[@prim_sens][i]
      raw := min_raw #> raw <# max_raw
      inputs.set_encoder(i + 1, raw)
      long[prim_target[i]] := raw / long[@prim_sens][i]
      if (i == 0) or (i == 4)   ' BPM (enc1) or SPB (enc5) changed
        FLAM_time_check          ' recalculate FLAM ticks
        oled_dirty_MASTER := 1

    old_enc[i] := inputs.get_encoder(i + 1)

    if k_KIT > n_KIT     'k cannot exceed n
      k_KIT := n_KIT
      inputs.set_encoder(3, k_KIT * long[@prim_sens][2])
      old_enc[2] := inputs.get_encoder(3)

    if k_PERC > n_PERC
      k_PERC := n_PERC
      inputs.set_encoder(7, k_PERC * long[@prim_sens][6])
      old_enc[6] := inputs.get_encoder(7)

 ' =================================================================================

PUB init_encoders | i

  prim_target[0] := @BPM
  prim_target[1] := @n_KIT
  prim_target[2] := @k_KIT
  prim_target[3] := @o_KIT
  prim_target[4] := @SPB
  prim_target[5] := @n_PERC
  prim_target[6] := @k_PERC
  prim_target[7] := @o_PERC

  alt_target[0] := @ALT_MASTER_1
  alt_target[1] := @vel_KIT
  alt_target[2] := @drum_idx_KIT
  alt_target[3] := @ALT_KIT_4 
  alt_target[4] := @FLAM_time  
  alt_target[5] := @vel_PERC
  alt_target[6] := @drum_idx_PERC
  alt_target[7] := @ALT_PERC_4

  
  repeat i from 0 to 7
    inputs.set_encoder(i + 1, long[@prim_init][i] * long[@prim_sens][i])

  alt_group1_active := 0
  alt_group2_active := 0
  alt_group3_active := 0
  
  repeat i from 0 to 7
    alt_val[i] := long[@alt_init][i]
    alt_raw[i] := 0

  waitcnt(cnt + clkfreq/100)
  repeat i from 0 to 7
    old_enc[i] := inputs.get_encoder(i + 1)


PUB update_oled_MASTER
'' Slow-changing fields only (BPM, SPB, FLAM_time, SWING) 
  if oled_dirty_MASTER == 0
    return
  OLEDs.select_display(MASTER)
  ' BPM
  OLEDs.goto_xy(80, 6)
  OLEDs.rjdec(BPM, 3, "0", FONT_BIG, PIXEL_ON)
  
  ' SPB
  OLEDs.goto_xy(54, 6)
  OLEDs.rjdec(SPB, 1, "0", FONT_BIG, PIXEL_ON)
  
  ' FLAM_time
  OLEDs.goto_xy(0, 2)

  if alt_group3_active
    OLEDs.str(string("Ft="), FONT_NORM, PIXEL_OFF)   ' reverse video
  else
    OLEDs.str(string("Ft="), FONT_NORM, PIXEL_ON)    ' normal

  
  OLEDs.rjdec(FLAM_time, 3, "0", FONT_NORM, PIXEL_ON)
  
  ' SWING - display ON or OFF
  OLEDs.goto_xy(100, 2)   ' Position after "SWING=" text
  if SWING == SWING_ON
    OLEDs.str(string("ON "), FONT_NORM, PIXEL_ON)
  else
    OLEDs.str(string("OFF"), FONT_NORM, PIXEL_ON)

    
  oled_dirty_MASTER := 0   ' Clear dirty flag after update

PUB update_oled_KIT   | bar_width
   if oled_dirty_KIT == 0
     return
  OLEDs.select_display(KIT)  
  OLEDs.goto_xy(8, 1)  
  OLEDs.rjdec(k_KIT, 2, "0", FONT_BIG, PIXEL_ON)
  OLEDs.goto_xy(50, 1)  
  OLEDs.rjdec(n_KIT, 2, "0", FONT_BIG, PIXEL_ON)
  OLEDs.goto_xy(98, 1)  
  OLEDs.rjdec(o_KIT, 1, "0", FONT_BIG, PIXEL_ON)
  OLEDs.goto_xy(4, 5) 
  OLEDs.str((GetDrumName(drum_idx_KIT)), FONT_NORM, PIXEL_ON)
  bar_width := (vel_KIT * 62) / 127
  OLEDs.draw_horizontal_bar(58, 5, bar_width)
  OLEDs.flush_page(KIT, 5)
  OLEDs.goto_xy(3, 7)  
    if alt_group1_active
      OLEDs.str(string("ALT"), FONT_NORM, PIXEL_OFF)
    else
      OLEDs.str(string("PRI"), FONT_NORM, PIXEL_ON)
  OLEDs.goto_xy(34, 7)  
    if MIDI_port_KIT == 0
      OLEDs.str(string("Prt:A"), FONT_NORM, PIXEL_ON)
    else
      OLEDs.str(string("Prt:B"), FONT_NORM, PIXEL_ON)
  OLEDs.goto_xy(86, 7)  
    if flam_enable_KIT == 1
      OLEDs.str(string("Flam"), FONT_NORM, PIXEL_ON)
    else
      OLEDs.str(string("OFF "), FONT_NORM, PIXEL_ON)


  oled_dirty_KIT := 0  ' Clear dirty flag after update  

PUB update_oled_PERC   | bar_width
   if oled_dirty_PERC == 0
     return
  OLEDs.select_display(PERC)
  OLEDs.goto_xy(8, 1)  
  OLEDs.rjdec(k_PERC, 2, "0", FONT_BIG, PIXEL_ON)

  OLEDs.goto_xy(50, 1)  
  OLEDs.rjdec(n_PERC, 2, "0", FONT_BIG, PIXEL_ON)

  OLEDs.goto_xy(98, 1)  
  OLEDs.rjdec(o_PERC, 1, "0", FONT_BIG, PIXEL_ON)

  OLEDs.goto_xy(4, 5) 
  OLEDs.str((GetDrumName(drum_idx_PERC)), FONT_NORM, PIXEL_ON)
  bar_width := (vel_PERC * 62) / 127
  OLEDs.draw_horizontal_bar(58, 5, bar_width)
  OLEDs.flush_page(PERC, 5)
  OLEDs.goto_xy(3, 7)  
    if alt_group2_active
      OLEDs.str(string("ALT"), FONT_NORM, PIXEL_OFF)
    else
      OLEDs.str(string("PRI"), FONT_NORM, PIXEL_ON)
  

   OLEDs.goto_xy(34, 7)  
    if MIDI_port_PERC == 0
      OLEDs.str(string("Prt:A"), FONT_NORM, PIXEL_ON)
    else
      OLEDs.str(string("Prt:B"), FONT_NORM, PIXEL_ON)
  OLEDs.goto_xy(86, 7)  
    if flam_enable_PERC == 1
      OLEDs.str(string("Flam"), FONT_NORM, PIXEL_ON)
    else
      OLEDs.str(string("OFF "), FONT_NORM, PIXEL_ON)
      
  oled_dirty_PERC := 0  ' Clear dirty flag after update


PUB init_OLEDs 
 OLEDs.startx(OLED_RST, OLED_DC, OLED_DATA, OLED_CLK, OLED_CS_1, OLED_CS_2,OLED_CS_3)
  
PUB update_oled_STEP | tens, units
'' Fastest possible update of JUST the ring_position digits.
'' Bypasses rjdec/dec (which loop through 10 divisor stages checking
'' billions down to units) -- ring_position is always 1..24, so we
'' compute the two digits directly and putc them. Touches nothing else.
 tens := ring_position / 10
  units := ring_position // 10
  OLEDs.select_display(MASTER) 
  OLEDs.goto_xy(2, 6)
  OLEDs.putc(tens + "0", FONT_BIG, PIXEL_ON)
  OLEDs.putc(units + "0", FONT_BIG, PIXEL_ON)

  
PUB Euclid1(ring_pos, n, k, o) : hit | s
  
'===================================================================================
' HIT ALGORITHMS
'===================================================================================


  hit := 0
  s := (ring_pos - 1) // n
  s := (s - o + n) // n
  hit := ((s * k) // n) < k




PUB show_euclid_pattern | i

  repeat i from 1 to 24
    if Euclid1(i, n_KIT, k_KIT, o_KIT) == -1
      pixbuf1[i - 1] := RED
    else
      pixbuf1[i - 1] := GREY

    if Euclid1(i, n_PERC, k_PERC, o_PERC) == -1
      pixbuf1[i + 23] := GREEN
    else
      pixbuf1[i + 23] := GREY

  if engine_state == 1
    highlight_current_step

PRI highlight_current_step
  if ring_position > 0
    if Euclid1(ring_position, n_KIT, k_KIT, o_KIT) == -1
      pixbuf1[ring_position-1] := BRIGHT_RED
    else
      pixbuf1[ring_position-1] := VIOLET
    if Euclid1(ring_position, n_PERC, k_PERC, o_PERC) == -1
      pixbuf1[ring_position+23] := BRIGHT_GREEN
    else
      pixbuf1[ring_position+23] := VIOLET

PRI check_euclid
  Euclid_KIT_changed := (n_KIT <> prev_n_KIT) or (k_KIT <> prev_k_KIT) or (o_KIT <> prev_o_KIT)
  if Euclid_KIT_changed
    prev_n_KIT := n_KIT
    prev_k_KIT := k_KIT
    prev_o_KIT := o_KIT
    show_euclid_pattern
    oled_dirty_KIT := 1    ' <-- Only KIT display 
  
  Euclid_PERC_changed := (n_PERC <> prev_n_PERC) or (k_PERC <> prev_k_PERC) or (o_PERC <> prev_o_PERC)
  if Euclid_PERC_changed
    prev_n_PERC := n_PERC
    prev_k_PERC := k_PERC
    prev_o_PERC := o_PERC
    show_euclid_pattern
    oled_dirty_PERC := 1   ' <-- Only PERC display

PUB max7219_display
  LED7SEG.ShowNum(1, BPM, 3)
  LED7SEG.ShowNum(4, SPB, 1)
  LED7SEG.ShowNum(5, ring_position, 2)
  LED7SEG.ShowNum(7, o_KIT, 1)
  LED7SEG.ShowNum(8, o_PERC, 1)
  LED7SEG.ShowNum(9, n_KIT, 2)
  LED7SEG.ShowNum(11, k_KIT, 2)
  LED7SEG.ShowNum(13, n_PERC, 2)
  LED7SEG.ShowNum(15, k_PERC, 2)

  case engine_state
    0: ' stopped
      LED7SEG.DPLED(5, 1)
      LED7SEG.DPLED(6, 1)
      LED7SEG.DPLED(1, 0)
      LED7SEG.DPLED(2, 0)
      LED7SEG.DPLED(3, 0)
      LED7SEG.DPLED(4, 0)
    1: 'running
      LED7SEG.DPLED(4, 1)
      LED7SEG.DPLED(3, 1)
      LED7SEG.DPLED(1, 0)
      LED7SEG.DPLED(2, 0)
      LED7SEG.DPLED(5, 0)
      LED7SEG.DPLED(6, 0)
    2: 'paused
      LED7SEG.DPLED(1, 1)
      LED7SEG.DPLED(2, 1)
      LED7SEG.DPLED(3, 0)
      LED7SEG.DPLED(4, 0)
      LED7SEG.DPLED(5, 0)
      LED7SEG.DPLED(6, 0)

  LED7SEG.DPLED(7, alt_group1_active)
  LED7SEG.DPLED(8, alt_group2_active)

CON
{{
----------------------------------------------------
MIDI reference values

Note ON  channel 10  =  $0x99 = 153
Note OFF channel 10  =  $0x89 = 137

General MIDI Drum Map
Hex   Dec  Instrument
0x23 |  35 | Bass Drum 2
0x24 |  36 | Bass Drum 1
0x25 |  37 | Side Stick
0x26 |  38 | Snare Drum 1
0x27 |  39 | Hand Clap
0x28 |  40 | Snare Drum 2
0x29 |  41 | Low Floor Tom
0x2A |  42 | Closed Hi-Hat
0x2B |  43 | High Floor Tom
0x2C |  44 | Pedal Hi-Hat
0x2D |  45 | Low Tom
0x2E |  46 | Open Hi-Hat
0x2F |  47 | Low-Mid Tom
0x30 |  48 | High-Mid Tom
0x31 |  49 | Crash Cymbal 1
0x32 |  50 | High Tom
0x33 |  51 | Ride Cymbal 1
0x34 |  52 | Chinese Cymbal
0x35 |  53 | Ride Bell
0x36 |  54 | Tambourine
0x37 |  55 | Splash Cymbal
0x38 |  56 | Cowbell
0x39 |  57 | Crash Cymbal 2
0x3A |  58 | Vibra Slap
0x3B |  59 | Ride Cymbal 2
0x3C |  60 | High Bongo
0x3D |  61 | Low Bongo
0x3E |  62 | Mute High Conga
0x3F |  63 | Open High Conga
0x40 |  64 | Low Conga
0x41 |  65 | High Timbale
0x42 |  66 | Low Timbale
0x43 |  67 | High Agogo
0x44 |  68 | Low Agogo
0x45 |  69 | Cabasa
0x46 |  70 | Maracas
0x47 |  71 | Short Whistle
0x48 |  72 | Long Whistle
0x49 |  73 | Short Guiro
0x4A |  74 | Long Guiro
0x4B |  75 | Claves
0x4C |  76 | High Wood Block
0x4D |  77 | Low Wood Block
0x4E |  78 | Mute Cuica
0x4F |  79 | Open Cuica
0x50 |  80 | Mute Triangle
0x51 |  81 | Open Triangle
}}